<?php $__env->startSection('content'); ?><div class="mx-auto max-w-lg py-12"><p class="text-xs uppercase tracking-[.3em] text-gold">Join the experience</p><h1 class="mt-3 font-display text-5xl">Create Account</h1><form method="POST" action="<?php echo e(route('register')); ?>" class="mt-8 space-y-4"><?php echo csrf_field(); ?>
<?php $__currentLoopData = ['name'=>'Full name','email'=>'Email address','phone'=>'Phone number']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field=>$label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><label class="block text-sm"><?php echo e($label); ?><input name="<?php echo e($field); ?>" value="<?php echo e(old($field)); ?>" type="<?php echo e($field==='email'?'email':'text'); ?>" class="form-input mt-2" <?php if($field!=='phone'): ?> required <?php endif; ?>></label><?php $__errorArgs = [$field];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="text-sm text-red-300"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<label class="block text-sm">Password<input name="password" type="password" required class="form-input mt-2"></label><label class="block text-sm">Confirm password<input name="password_confirmation" type="password" required class="form-input mt-2"></label><button class="w-full rounded-full bg-gold px-6 py-3 font-semibold text-olive">Create account</button></form><p class="mt-6 text-sm text-cream/60">Already registered? <a class="text-gold" href="<?php echo e(route('login')); ?>">Login</a></p></div><?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/adamroxannirsyad/Documents/Right/free-ticket-war-starter/resources/views/auth/register.blade.php ENDPATH**/ ?>