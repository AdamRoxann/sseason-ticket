<!doctype html>
<html lang="id">
<head>
    <meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo e($title ?? 'A SSeason to Bloom'); ?> · Sheila Saukia</title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css','resources/js/app.js']); ?>
</head>
<body class="min-h-screen bg-olive text-cream antialiased">
<header class="mx-auto flex max-w-7xl items-center justify-between px-6 py-6">
    <a href="<?php echo e(route('home')); ?>" class="font-display text-3xl tracking-tight">SS<span class="text-gold">.</span></a>
    <nav class="flex items-center gap-4 text-sm">
        <?php if(auth()->guard()->check()): ?> <a href="<?php echo e(route('tickets.index')); ?>" class="hover:text-gold">My Tickets</a><form method="POST" action="<?php echo e(route('logout')); ?>"><?php echo csrf_field(); ?><button class="hover:text-gold">Logout</button></form>
        <?php else: ?> <a href="<?php echo e(route('login')); ?>" class="hover:text-gold">Login</a><a href="<?php echo e(route('register')); ?>" class="rounded-full bg-gold px-4 py-2 font-semibold text-olive">Create Account</a> <?php endif; ?>
    </nav>
</header>
<main class="mx-auto max-w-7xl px-6 pb-20"><?php if(session('success')): ?><div class="mb-6 rounded-xl border border-gold/40 bg-gold/10 p-4 text-gold"><?php echo e(session('success')); ?></div><?php endif; ?> <?php echo $__env->yieldContent('content'); ?></main>
<footer class="border-t border-cream/10 px-6 py-8 text-center text-xs text-cream/50">© <?php echo e(date('Y')); ?> ASIARIGHT. All Rights Reserved.</footer>
</body></html>
<?php /**PATH /Users/adamroxannirsyad/Documents/Right/free-ticket-war-starter/resources/views/layouts/app.blade.php ENDPATH**/ ?>