<?php $__env->startSection('content'); ?><div class="mx-auto max-w-xl py-12"><p class="text-xs uppercase tracking-[.3em] text-gold">Your turn</p><h1 class="mt-3 font-display text-5xl">Confirm your ticket</h1><p class="mt-4 text-sm text-cream/65">Choose the available ticket category and quantity. Your access expires at <?php echo e($entry->expires_at?->timezone('Asia/Jakarta')->format('H:i:s')); ?> WIB.</p><form method="POST" action="<?php echo e(route('waiting-room.checkout',$entry)); ?>" class="mt-8 space-y-5"><?php echo csrf_field(); ?><label class="block text-sm">Ticket category<select name="ticket_category_id" class="form-input mt-2" required><?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?> — <?php echo e($category->remaining); ?> remaining</option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></label><label class="block text-sm">Quantity<select name="quantity" class="form-input mt-2"><?php for($i=1;$i<=min((int)config('ticketwar.max_per_user',2),2);$i++): ?><option value="<?php echo e($i); ?>"><?php echo e($i); ?></option><?php endfor; ?></select></label><?php $__errorArgs = ['quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="text-sm text-red-300"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> <?php $__errorArgs = ['ticket_category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="text-sm text-red-300"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><button class="w-full rounded-full bg-gold px-6 py-3 font-semibold text-olive">Confirm & Get Ticket</button></form></div><?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/adamroxannirsyad/Documents/Right/free-ticket-war-starter/resources/views/tickets/checkout.blade.php ENDPATH**/ ?>